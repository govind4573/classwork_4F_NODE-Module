const calc=require('./calc')

console.log(calc.addition(10,20))
console.log(calc.difference(10,20))