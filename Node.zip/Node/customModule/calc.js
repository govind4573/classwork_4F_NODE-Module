function add(a,b){
    return a+b 

}

let sub=(a,b)=>{return a-b}

expoorts.addition=add
exports.difference=sub

